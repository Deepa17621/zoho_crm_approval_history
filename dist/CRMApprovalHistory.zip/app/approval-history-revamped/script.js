//Global Variables
let filterObject = {
    module: "",
    action: "",
    search: "",
    timeBase: ""
};

// ==============================
// CALENDAR STATE (PERSISTENT)
// ==============================
const calendarState = {
    initialized: false,
    mode: "single",
    current: new Date(),
    startDate: null,
    endDate: null
};

let specificDateFilter = '', rangeDateFilter = [];
let allRecords = {};
let env_details;
let allModules = {};
let recordsCountPerPage = 10;
let currentPage = 1;
let allRecordsArray = [];
let totalPages = '';

// Elements 
let searchRecordInput = document.querySelector("#global-search");
let clearFilterWrapper = document.querySelector("#clr-filter-wrapper");
let tableBody = document.querySelector("#main-table__body");
let paginationSelect = document.querySelector("#pagination-select");
let paginationPrevBtn = document.querySelector("#pagination-prev-btn");
let paginationNextBtn = document.querySelector("#pagination-next-btn");
let paginationPageTxt = document.querySelector(".pagination-page-no-txt");


ZOHO.embeddedApp.on("PageLoad", async function (data) {

    // i. Get Environment Details
    env_details = await ZOHO.CRM.CONFIG.GetCurrentEnvironment();

    // 1. Get Approval History and Filter the Records - map the duplicated under single record ID.
    let approvalHistory = await getApprovals();

    // GET ALL MODULES TO GET API Names of the Module
    let allModulesResponse = await ZOHO.CRM.META.getModules();
    let allModulesData = await allModulesResponse;
    allModulesData.modules.forEach(element => {
        allModules[element["module_name"]] = element["api_name"];
    });

    // Filter the present Modules name from current Approval Records.
    let currentApprovalModules = Object.keys(approvalHistory).reduce((acc, val) => {
        acc[approvalHistory[`${val}`][0]["module"]] = (acc[approvalHistory[`${val}`][0]["module"]] || 0) + 1;
        return acc;
    }, {});

    // 2. Build Table with records
    buildTable(approvalHistory);
    if (currentPage == 1) {
        paginationPrevBtn.disabled = true;
        paginationNextBtn.disabled = false;
    }
    else if (currentPage == totalPages) {
        paginationNextBtn.disabled = true;
        paginationPrevBtn.disabled = false;
    }
    else {
        paginationPrevBtn.disabled = false;
        paginationNextBtn.disabled = false;
    }

    // Add Modules to the Dropdown of the Modules Column 
    let moduelsDropDownContainer = document.querySelector("#module-filter-list");

    for (const moduleName in currentApprovalModules) {
        let optionDiv = document.createElement("div");
        optionDiv.classList.add("filter-dropdown__option");
        optionDiv.setAttribute("role", "option");
        optionDiv.setAttribute("aria-selected", "false");
        optionDiv.setAttribute("data-value", moduleName)
        optionDiv.textContent = moduleName;
        moduelsDropDownContainer.appendChild(optionDiv);
    }
    // Handle all dropdown headers
    // document.querySelectorAll(".filter-dropdown__trigger").forEach(header => {
    //     const dropdownId = header.dataset.dropdown;
    //     const labelId = header.dataset.label;
    //     const dropdown = document.getElementById(dropdownId);
    //     const label = document.getElementById(labelId);

    //     const searchInput = dropdown.querySelector(".filter-dropdown__search");
    //     const options = Array.from(dropdown.querySelectorAll(".filter-dropdown__option"));

    //     // Open/close dropdown on click
    //     header.addEventListener("click", function (event) {
    //         const isOpen = dropdown.style.display === "flex";
    //         // Close all other dropdowns
    //         document.querySelectorAll(".filter-dropdown__menu").forEach(d => d.style.display = "none");

    //         dropdown.style.display = isOpen ? "none" : "flex";
    //         filterOptions();
    //         searchInput.focus();
    //         event.stopPropagation();
    //     });

    //     // Update label and tick on option click
    //     options.forEach(option => {
    //         option.addEventListener("click", function () {
    //             // document.querySelector("#clr-filter-txt").style.display = "block";
    //             options.forEach(opt => {
    //                 opt.setAttribute("aria-selected", "false");
    //                 opt.classList.remove("selected");
    //             });
    //             this.classList.add("selected");
    //             this.setAttribute("aria-selected", "true");
    //             label.textContent = this.dataset.value;

    //             switch (label.id) {
    //                 case "moduleLabel":
    //                     filterObject.module = this.dataset.value;
    //                     break;

    //                 case "statusLabel":
    //                     if (this.dataset.value === "Pending") {
    //                         filterObject.action = ["Submitted", "Delegated"];
    //                     } else if (this.dataset.value === "Approved") {
    //                         filterObject.action = "Final_Approval";
    //                     } else {
    //                         filterObject.action = this.dataset.value;
    //                     }
    //                     break;
    //                 case "timeFilterLabel":
    //                     if (this.dataset.value === "on") {

    //                         document.querySelector(".filter-dropdown__calendar").style.display = "block";
    //                         filterObject.timeBase = this.dataset.value;
    //                         buildCalendar("single-calendar", "single", (date, selectedDate = "") => {
    //                             let d = new Date(date);
    //                             specificDateFilter = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    //                             if (specificDateFilter) {
    //                                 applyFilter(filterObject, specificDateFilter);
    //                                 document.querySelector(".filter-dropdown__calendar").style.display = "none";
    //                             }
    //                         });
    //                         break;
    //                     }
    //                     else if (this.dataset.value === "between") {

    //                         filterObject.timeBase = this.dataset.value;
    //                         document.querySelector(".filter-dropdown__calendar").style.display = "block";
    //                         buildCalendar("single-calendar", "range", (start, end, selectedDate = {}) => {
    //                             if (end) {
    //                                 let startDate = new Date(start);
    //                                 rangeDateFilter[0] = `${startDate.getFullYear()}-${String(startDate.getMonth() + 1).padStart(2, '0')}-${String(startDate.getDate()).padStart(2, '0')}`;
    //                                 let endDate = new Date(end);
    //                                 rangeDateFilter[1] = `${endDate.getFullYear()}-${String(endDate.getMonth() + 1).padStart(2, '0')}-${String(endDate.getDate()).padStart(2, '0')}`;
    //                                 if (rangeDateFilter[0] && rangeDateFilter[1]) {
    //                                     applyFilter(filterObject, rangeDateFilter[0]);
    //                                     document.querySelector(".filter-dropdown__calendar").style.display = "none";
    //                                 }
    //                             }
    //                         });
    //                         break;
    //                     }
    //                     filterObject.timeBase = this.dataset.value;
    //                     break;
    //             }
    //             switch (this.dataset.value) {
    //                 case "All Modules":
    //                     filterObject.module = "";
    //                     break;
    //                 case "All Status":
    //                     filterObject.action = "";
    //                     break;
    //                 case "Anytime":
    //                     filterObject.timeBase = "";
    //                     break;
    //             }

    //             if (filterObject.timeBase.trim() == "between" || filterObject.timeBase.trim() == "on") {
    //             }
    //             else {
    //                 applyFilter(filterObject);
    //             }
    //             checkFilters();
    //             dropdown.style.display = "none";
    //         });
    //     });

    //     // Filter options based on search input
    //     searchInput.addEventListener("input", filterOptions);

    //     function filterOptions() {
    //         const filter = searchInput.value.toLowerCase();
    //         options.forEach(option => {
    //             option.style.display = option.dataset.value.toLowerCase().includes(filter) ? "flex" : "none";
    //         });
    //     }
    // });

    // New Code to Handle dropdowns
    // ==============================
    // DROPDOWNS
    // ==============================
    document.querySelectorAll(".filter-dropdown__trigger").forEach(header => {

        const dropdown = document.getElementById(header.dataset.dropdown);
        let calendarWrapper = document.querySelector(".filter-dropdown__calendar");

        const label = document.getElementById(header.dataset.label);

        const searchInput = dropdown.querySelector(".filter-dropdown__search");
        const options = dropdown.querySelectorAll(".filter-dropdown__option");

        // OPEN / CLOSE
        header.addEventListener("click", e => {

            const isOpen =
                getComputedStyle(dropdown).display === "flex";

            document.querySelectorAll(".filter-dropdown__menu")
                .forEach(d => d.style.display = "none");

            if (getComputedStyle(calendarWrapper).display === "block") {
                calendarWrapper.style.display = "none";
            }

            dropdown.style.display = isOpen ? "none" : "flex";

            searchInput.focus();
            e.stopPropagation();
        });

        // OPTION CLICK
        options.forEach(option => {

            option.addEventListener("click", function () {

                options.forEach(o => {
                    o.classList.remove("selected");
                    o.setAttribute("aria-selected", "false");
                });

                this.classList.add("selected");
                this.setAttribute("aria-selected", "true");

                label.textContent = this.textContent.trim();

                const val = this.dataset.value;

                switch (label.id) {
                    case "moduleLabel":
                        filterObject.module = this.dataset.value;
                        break;

                    case "statusLabel":
                        if (this.dataset.value === "Pending") {
                            filterObject.action = ["Submitted", "Delegated"];
                        } else if (this.dataset.value === "Approved") {
                            filterObject.action = "Final_Approval";
                        } else {
                            filterObject.action = this.dataset.value;
                        }
                        break;

                    case "timeFilterLabel":

                        if (val === "on") {
                            filterObject.timeBase = "on";

                            initCalendar();

                            // if (calendarState.mode === "range") {
                            //     let selectedDays = document.querySelectorAll(".calendar-day.range");
                            //     // calendarState.startDate = null;
                            //     // calendarState.endDate = null;

                            //     [...selectedDays].forEach(element => {

                            //         element.classList.remove("range");
                            //         if (element.classList.contains("selected")) element.classList.remove("selected");
                            //     });
                            // }
                            calendarState.mode = "single";

                            document.querySelector(".filter-dropdown__calendar")
                                .style.display = "block";

                            break;
                        }

                        if (val === "between") {

                            filterObject.timeBase = "between";

                            initCalendar();

                            // if (calendarState.mode === "single") {
                            //     let selectedDays = document.querySelectorAll(".calendar-day.selected");

                            //     // calendarState.startDate = null;
                            //     // calendarState.endDate = null;

                            //     [...selectedDays].forEach(element => {
                            //         element.classList.remove("selected");
                            //     });
                            // }

                            calendarState.mode = "range";

                            document.querySelector(".filter-dropdown__calendar")
                                .style.display = "block";

                            break;
                        }

                        filterObject.timeBase = val;
                        break;
                }
                switch (this.dataset.value) {
                    case "All Modules":
                        filterObject.module = "";
                        break;
                    case "All Status":
                        filterObject.action = "";
                        break;
                    case "Anytime":
                        filterObject.timeBase = "";
                        break;
                }
                if (
                    val !== "on" &&
                    val !== "between"
                ) {
                    applyFilter(filterObject);
                }
                checkFilters();
                dropdown.style.display = "none";
            });
        });

        // SEARCH
        searchInput.addEventListener("input", filterOptions);
        function filterOptions(e) {
            const filter = searchInput.value.toLowerCase();
            let matchFound = false;

            options.forEach(option => {

                if (option.dataset.value.toLowerCase().includes(filter)) {
                    option.style.display = "flex";
                    matchFound = true;
                } else {
                    option.style.display = "none";
                }

            });
            let noResult = dropdown.querySelector(".no-results");

            if (!matchFound) {
                if (!noResult) {
                    noResult = document.createElement("div");
                    noResult.className = "no-results";
                    noResult.textContent = "No results found";
                    dropdown.appendChild(noResult);
                }

            } else {

                if (noResult) {
                    noResult.remove();
                }
            }
        }
    });

    function checkFilters() {
        const selectedModule =
            document.querySelector("#module-filter-list .selected").dataset.value;

        const selectedStatus = document.querySelector("#status-filter-list .selected").dataset.value;
        const selectedTime = document.querySelector("#time-filter-list .selected").dataset.value;
        const clearBtn = document.getElementById("clr-filter-txt");

        if (selectedModule !== "All Modules" || selectedStatus !== "All Status" || selectedTime !== "Anytime") {
            clearBtn.style.display = "block";
        } else {
            clearBtn.style.display = "none";
        }
    }

    document.querySelector("#global-search").addEventListener("input", (e) => {
        filterObject["search"] = e.target.value.trim();
        applyFilter(filterObject);
    })

    //Pagination Select Event
    paginationSelect.addEventListener("change", (e) => {
        e.preventDefault();
        recordsCountPerPage = paginationSelect.value;
        currentPage = 1;
        totalPages = Math.ceil(allRecordsArray.length / recordsCountPerPage);
        paginationPageTxt.innerHTML = `${currentPage}&nbsp; of &nbsp;${totalPages}`;
        renderTable(currentPage, recordsCountPerPage, allRecordsArray);
    })

    // Clear All Filter
    document.querySelector("#clr-filter-txt").addEventListener("click", clearFilter);
    window.addEventListener('click', (e) => {
        let flag = false;
        let popUps = document.querySelectorAll(".filter-dropdown__menu");
        popUps.forEach(element => {
            if (element.contains(e.target)) flag = true;
            if (!flag) {
                element.style.display = "none";
            }

        });
        let calendar = document.querySelector(".filter-dropdown__calendar");
        if (calendar.contains(e.target)) flag = true;
        if (!flag) {
            calendar.style.display = "none";
        }
        // const clickedInsidePopup = popup.contains(e.target);
        // const clickedButton = btn.contains(e.target);

        // if (!flag) {
        //      // or style.display = 'none';
        // }
    });
});


async function getApprovals() {
    let approvalHistory = await ZOHO.CRM.API.getApprovalsHistory();
    let data = await approvalHistory;

    const filteredObject = data.data.reduce((acc, item) => {
        if (!acc[item.record.id]) {
            acc[item.record.id] = [];
        }
        acc[item.record.id].push(item);
        return acc;
    }, {});
    return filteredObject;
}

async function buildTable(filteredObject) {
    allRecords = filteredObject;
    applyFilter({});
}


async function applyFilter(filters, d = "") {
    currentPage = 1;
    const filtered = getFilteredRecords(filters, d);
    renderTable(currentPage, recordsCountPerPage, filtered);
}

function renderTable(currentPage, recordsPerPage, records) {
    const tbody = document.getElementById("main-table__body");
    tbody.innerHTML = ""; // clear existing rows

    allRecordsArray = records;
    startIndex = (currentPage - 1) * recordsPerPage;
    endIndex = Number(startIndex) + Number(recordsPerPage);
    totalPages = Math.ceil(allRecordsArray.length / recordsPerPage);
    paginationPageTxt.innerHTML = `${currentPage}&nbsp; of &nbsp;${totalPages}`;

    if (records.length <= 0) {
        let noRecordFoundHtml = `
             <tr class="no-records-found-tr">
                <td colspan="4" style="text-align: center; padding: 20px;">
                    <img src="../assets/no_record_img.jpg" alt="no records found!">
                    <div class="no-records-found-txt">No records match your filter</div>
                </td>
            </tr>   
        `;
        tbody.innerHTML = noRecordFoundHtml;
    }
    else {
        let filteredRecordsArray = records.slice(startIndex, endIndex);
        filteredRecordsArray.forEach((record, index) => {
            tbody.appendChild(createRow(record, index));
            tbody.appendChild(createApproverRow(record, index));
        });
    }
}

paginationNextBtn.addEventListener("click", (e) => {
    e.preventDefault();
    if (currentPage == totalPages - 1) {
        paginationNextBtn.disabled = true;
        paginationPrevBtn.disabled = false;
    }
    else {
        paginationPrevBtn.disabled = false;
        paginationNextBtn.disabled = false;
    }
    if (currentPage < totalPages) {
        currentPage++;
        renderTable(currentPage, recordsCountPerPage, allRecordsArray);
    }

});

paginationPrevBtn.addEventListener("click", (e) => {
    e.preventDefault();
    if (currentPage == 2 || currentPage == 1) {
        paginationPrevBtn.disabled = true;
        paginationNextBtn.disabled = false;
    }
    else {
        paginationPrevBtn.disabled = false;
        paginationNextBtn.disabled = false;
    }
    if (currentPage > 1) {
        currentPage--;
        renderTable(currentPage, recordsCountPerPage, allRecordsArray);
    }
})
function getFilteredRecords(filters, d = "") {
    let result = [];
    let today = new Date();
    let yesterday = new Date();
    let sevenDaysAgo = new Date();
    let thirtyDaysAgo = new Date();

    yesterday.setDate(today.getDate() - 1);
    sevenDaysAgo.setDate(today.getDate() - 7);
    thirtyDaysAgo.setDate(today.getDate() - 30);

    for (const id in allRecords) {
        const record = allRecords[id][0];

        // Skip default unwanted records
        // if (record.action === "Submitted" && allRecords[id].length === 1) {
        //     continue;
        // }

        let match = true;

        // Check each filter
        for (const key in filters) {
            if (!filters[key]) continue;
            if (key == "search") {
                const searchText = filters.search.toLowerCase();
                const name = record.record.name.toLowerCase();

                if (!name.includes(searchText)) {
                    match = false;
                    break;
                }
                continue;
            }
            else if (key === "action") {
                // Module / Status / Action filters
                const allowed = key === "action" ? filters[key] : [filters[key]];
                if (!allowed.includes(record[key])) {
                    match = false;
                    break;
                }
            }
            else if (key === "module") {
                if (filterObject.module !== record.module) {
                    match = false;
                    break;
                }
            }
            // Time Based Filter
            else if (key === "timeBase") {
                let recordAuditTime = new Date(record.audit_time);
                let date = new Date(recordAuditTime);
                let formatted = date.toISOString().slice(0, 10);
                if (filterObject[key] == "Today") {
                    if (today !== recordAuditTime) {
                        match = false;
                        break;
                    }
                }
                else if (filterObject[key] === "last-7") {
                    if (recordAuditTime < sevenDaysAgo || recordAuditTime > today) {
                        match = false;
                        break;
                    }
                }

                else if (filterObject[key] === "last-30") {
                    if (recordAuditTime < thirtyDaysAgo || recordAuditTime > today) {
                        match = false;
                        break;
                    }
                }
                else if (filterObject[key].trim() == "on") {
                    if (formatted !== specificDateFilter) {
                        match = false;
                        break;
                    }
                }
                else if (filterObject[key].trim() == "between") {
                    if (!(new Date(rangeDateFilter[0]) <= new Date(formatted)) || !(new Date(rangeDateFilter[1]) >= new Date(formatted))) {
                        match = false;
                        break;
                    }
                }

            }
        }
        if (match) {
            result.push(allRecords[id]);
        }
    }
    return result;
}


function clearFilter() {
    document.querySelector(".filter-dropdown__calendar").style.display = "none";
    document.querySelector("#clr-filter-txt").style.display = "none";

    for (const key in filterObject) {
        filterObject[key] = "";
    }
    calendarState.startDate = null;
    calendarState.endDate = null;
    let selectedOptions = document.querySelectorAll(".selected");
    selectedOptions.forEach(element => {
        if (element.dataset.default) { }
        else {
            element.classList.remove("selected");
            element.setAttribute("aria-selected", "false");
        }
    });
    let defaultOptions = document.querySelectorAll('[data-default="true"]');
    defaultOptions.forEach(element => {
        if (!element.classList.contains("selected")) {
            element.classList.add("selected");
            element.setAttribute("aria-selected", "true");
        }
    });
    document.querySelector("#global-search").value = "";
    document.querySelector("#moduleLabel").textContent = "All Modules";
    document.querySelector("#statusLabel").textContent = "All Status";
    document.querySelector("#timeFilterLabel").textContent = "Anytime";
    applyFilter({});
}

// ---------------- CREATE ROW ELEMENTS ---------------------

function createRow(obj, index) {
    const wrapper = document.createElement("tr");
    const data = obj[0];

    const overAllStatus =
        data.action === "Final_Approval"
            ? "Approved"
            : data.action === "Submitted" || data.action === "Delegated"
                ? "Pending"
                : data.action;

    wrapper.className = "row";
    wrapper.dataset.id = data.record.id;
    wrapper.dataset.value = data.module;

    wrapper.innerHTML = `
        <td class="recordName"><span id="record-name">${data.record.name}</span></td>
        <td>${data.module}</td>
        <td><span class="tag ${overAllStatus.toLowerCase()}">${overAllStatus}</span></td>
        <td><span class="view-approver-details-trigger" onclick="toggle(event, ${index})">View Details</span></td>
    `;
    if (wrapper.querySelector(".recordName").scrollWidth > wrapper.querySelector(".recordName").clientWidth) {
        wrapper.querySelector(".recordName").title = wrapper.querySelector(".recordName").textContent.trim();
    }
    // Add record click event
    wrapper.querySelector("#record-name").addEventListener("click", () => {
        viewRecord(data);
    });

    return wrapper;
}


function createApproverRow(obj, index) {
    const row = document.createElement("tr");
    row.className = "approver-row";
    row.id = `approver-${index}`;
    row.style.display = "none";

    row.innerHTML = `
        <td colspan="4">
            <table class="mini-table">
                <thead>
                    <tr>
                        <th>Approver Name</th>
                        <th>Status</th>
                        <th>Event Time</th>
                        <th>Comments</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </td>
    `;

    return row;
}

function viewRecord(data) {

    const domainDetails = {
        "US": ".com",
        "AU": ".com.au",
        "EU": ".eu",
        "IN": ".in",
        "CN": ".com.cn",
        "JP": ".jp",
        "CA": ".zohocloud.ca"
    };

    window.open(
        `https://crm.zoho${domainDetails[env_details.deployment]}/crm/org${env_details.zgid}/tab/${data.module}/${data.record.id}/`
    );
}

async function toggle(event, index) {
    let connectionName = "approvalhistory";
    let allRows = document.querySelectorAll(".approver-row");

    const row = document.getElementById(`approver-${index}`);
    const mainRow = row.previousElementSibling;
    const id = mainRow.dataset.id;
    const module = mainRow.dataset.value;

    if (!event.target.classList.contains("selectedZBTN")) {
        event.target.classList.add("selectedZBTN");
        row.classList.add("currentRow");
        mainRow.classList.add("currentRow");
    }
    else {
        event.target.classList.remove("selectedZBTN");
        row.classList.remove("currentRow");
        mainRow.classList.remove("currentRow");
    }

    row.style.display = row.style.display === "table-row" ? "none" : "table-row";

    allRows.forEach(element => {
        if (element.id !== row.id) {
            element.classList.remove(".currentRow");
            let zbtn = element.previousElementSibling.querySelector(".view-approver-details-trigger");
            if (zbtn.classList.contains("selectedZBTN")) {
                zbtn.classList.remove("selectedZBTN");
                zbtn.textContent = "View Details";
            }

            element.style.display = "none";
        }
    });
    let moduleAPIName = allModules[module];

    // 4. TimeLine Details to get comments
    let url = `https://www.zohoapis.com/crm/v8/${module === "Potentials" ? "Deals" : moduleAPIName}/${id}/__timeline?filters=%7B%22field%22%3A%7B%22api_name%22%3A%22source%22%7D%2C%22comparator%22%3A%22equal%22%2C%22value%22%3A%22approval_process%22%7D%20`;
    let req_data = {
        "url": url,
        "method": "GET",
    }
    ZOHO.CRM.CONNECTION.invoke(connectionName, req_data).then(function (data) {
        // //------------------------Approval Details
        // var req_data1 = {
        //         "method": "GET",
        //         "url": `https://crm.zoho.com/crm/v2.2/${module}/${id}/actions/approval_details`,
        //     };
        //     ZOHO.CRM.CONNECTION.invoke(connectionName, req_data1).then(function (data) {
        //         console.log(data)
        //     });

        // //---------------------
        let stages = data.details?.statusMessage?.__timeline;
        let trs = '';
        for (let j = stages.length == 1 ? 0 : stages.length - 2; j >= 0; j--) {
            const date = new Date(stages[j].audited_time);
            const options = { month: "short", day: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", hour12: true };
            const formattedAuditedTime = date.toLocaleString("en-US", options).replace(",", "");

            if (stages[j].action === "updated") continue;

            let status = '', comments = '';
            if (stages[j].action === "final_approval") {
                status = "Approved";
            }
            else if ((stages[j].action).toLowerCase() == "submitted" || stages[j].action == "task_assigned") {
                status = "Pending";
                comments = "Not yet provided";
            }
            else {
                status = stages[j].action;
                status = `${status.charAt(0).toUpperCase()}${status.slice(1)}`;

            }

            trs += `<tr>
                                <td>${stages[j].done_by.name}</td>
                                <td><span class="tag ${status.toLowerCase()}">${status}</span></td>
                                <td>${formattedAuditedTime}</td>
                                <td>${stages[j].automation_details.approval_process?.comments || (status === "Pending" ? comments : "-")}</td>
                            </tr>`
        }
        let miniTable = row.querySelector(".mini-table").querySelector("tbody");
        miniTable.innerHTML = trs;
    });

}

//Time Based Filter - (I. Specific date && II. Date Range)
// UNIVERSAL CALENDAR (supports single + range modes)
// function buildCalendar(containerId, mode, onSelect) {
//     const container = document.getElementById(containerId);
//     container.className = "calendar";

//     let current = new Date();
//     let startDate = null;
//     let endDate = null;

//     function render() {
//         const year = current.getFullYear();
//         const month = current.getMonth();
//         const firstDay = new Date(year, month, 1).getDay();
//         const daysInMonth = new Date(year, month + 1, 0).getDate();
//         container.innerHTML = "";

//         // Header
//         const header = document.createElement("div");
//         header.className = "calendar-header";

//         const prev = document.createElement("button");
//         prev.textContent = "<";
//         prev.onclick = () => {
//             current = new Date(year, month - 1, 1);
//             render();
//         };

//         const next = document.createElement("button");
//         next.textContent = ">";
//         next.onclick = () => {
//             current = new Date(year, month + 1, 1);
//             render();
//         };

//         const title = document.createElement("div");
//         title.textContent = `${current.toLocaleString("default", { month: "long" })} ${year}`;

//         header.appendChild(prev);
//         header.appendChild(title);
//         header.appendChild(next);
//         container.appendChild(header);

//         // Grid
//         const grid = document.createElement("div");
//         grid.className = "calendar-grid";

//         const weekNames = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];
//         weekNames.forEach(d => {
//             const el = document.createElement("div");
//             // el.style.fontWeight = "bold";
//             el.textContent = d;
//             grid.appendChild(el);
//         });

//         // Empty spaces
//         for (let i = 0; i < firstDay; i++) {
//             grid.appendChild(document.createElement("div"));
//         }

//         // Days
//         for (let day = 1; day <= daysInMonth; day++) {
//             const dateObj = new Date(year, month, day);

//             const el = document.createElement("div");
//             el.textContent = day;
//             el.className = "calendar-day";

//             // Single mode highlight
//             if (mode === "single" && startDate &&
//                 dateObj.toDateString() === startDate.toDateString()) {
//                 el.classList.add("selected");

//             }

//             // Range mode highlight
//             if (mode === "range" && startDate && endDate) {
//                 if (dateObj >= startDate && dateObj <= endDate) {
//                     el.classList.add("range");
//                 }
//                 if (
//                     dateObj.toDateString() === startDate.toDateString() ||
//                     dateObj.toDateString() === endDate.toDateString()
//                 ) {
//                     el.classList.add("selected");

//                 }
//             }

//             el.onclick = () => {
//                 if (mode === "single") {
//                     // if (dateObj > current) {
//                     //     el.style.cursor = "not-allowed";
//                     // }
//                     // else {
//                     startDate = dateObj;
//                     el.setAttribute("data-ondate", "true");
//                     onSelect(startDate, el);
//                     // }
//                 }

//                 if (mode === "range") {
//                     // if (dateObj > current) {
//                     //     el.style.cursor = "not-allowed";
//                     // }
//                      el.setAttribute("data-betweendate", "true");
//                     if (!startDate || (startDate && endDate)) {
//                         startDate = dateObj;
//                         endDate = null;
//                     } else if (dateObj >= startDate) {
//                         endDate = dateObj;
//                         onSelect(startDate, endDate);
//                     } else {
//                         startDate = dateObj;
//                         endDate = null;
//                     }
//                 }

//                 render();
//             };

//             grid.appendChild(el);
//         }

//         container.appendChild(grid);
//     }

//     render();
// }

// ==============================
// GLOBAL FILTER STATE
// ==============================
// const filterObject = {
//     module: "",
//     action: "",
//     timeBase: ""
// };

// let specificDateFilter = "";
// let rangeDateFilter = ["", ""];

// ==============================
// INIT CALENDAR ONLY ONCE
// ==============================
function initCalendar() {
    if (calendarState.initialized) return;

    buildCalendar(
        "single-calendar",
        calendarState,
        handleCalendarSelect
    );

    calendarState.initialized = true;
}

// ==============================
// CALENDAR CALLBACK
// ==============================
function handleCalendarSelect(start, end = null) {

    if (calendarState.mode === "single") {
        const d = new Date(start);

        specificDateFilter =
            `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

        applyFilter(filterObject, specificDateFilter);
    }

    if (calendarState.mode === "range" && end) {

        const s = new Date(start);
        const e = new Date(end);

        rangeDateFilter[0] =
            `${s.getFullYear()}-${String(s.getMonth() + 1).padStart(2, "0")}-${String(s.getDate()).padStart(2, "0")}`;

        rangeDateFilter[1] =
            `${e.getFullYear()}-${String(e.getMonth() + 1).padStart(2, "0")}-${String(e.getDate()).padStart(2, "0")}`;

        applyFilter(filterObject, rangeDateFilter[0]);
    }

    document.querySelector(".filter-dropdown__calendar").style.display = "none";
}

// ==============================
// BUILD CALENDAR (STATE BASED)
// ==============================
function buildCalendar(containerId, state, onSelect) {

    const container = document.getElementById(containerId);
    container.addEventListener("click", function (event) {
        event.stopPropagation();
    });

    function render() {

        const year = state.current.getFullYear();
        const month = state.current.getMonth();

        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();

        container.innerHTML = "";

        // HEADER
        const header = document.createElement("div");
        header.className = "calendar-header";

        const prev = document.createElement("button");
        prev.textContent = "<";
        prev.onclick = () => {
            state.current = new Date(year, month - 1, 1);
            render();
        };

        const next = document.createElement("button");
        next.textContent = ">";
        next.onclick = () => {
            state.current = new Date(year, month + 1, 1);
            render();
        };

        const title = document.createElement("div");
        title.textContent =
            `${state.current.toLocaleString("default", { month: "long" })} ${year}`;

        header.append(prev, title, next);
        container.appendChild(header);

        // GRID
        const grid = document.createElement("div");
        grid.className = "calendar-grid";

        ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"].forEach(day => {
            const d = document.createElement("div");
            d.textContent = day;
            grid.appendChild(d);
        });

        // EMPTY CELLS
        for (let i = 0; i < firstDay; i++) {
            grid.appendChild(document.createElement("div"));
        }

        // DAYS
        for (let day = 1; day <= daysInMonth; day++) {

            const dateObj = new Date(year, month, day);


            const cell = document.createElement("div");
            cell.className = "calendar-day";
            cell.textContent = day;

            const today = new Date();
            today.setHours(0, 0, 0, 0);

            const isFuture = dateObj > today;

            if (isFuture) {
                cell.classList.add("disabled-date");
                cell.setAttribute("aria-disabled", "true");
            }

            // SINGLE MODE
            if (
                state.mode === "single" &&
                state.startDate &&
                dateObj.toDateString() === state.startDate.toDateString()
            ) {
                cell.classList.add("selected");
            }

            // RANGE MODE
            if (
                state.mode === "range" &&
                state.startDate &&
                state.endDate
            ) {
                if (dateObj >= state.startDate && dateObj <= state.endDate) {
                    cell.classList.add("range");
                }

                if (
                    dateObj.toDateString() === state.startDate.toDateString() ||
                    dateObj.toDateString() === state.endDate.toDateString()
                ) {
                    cell.classList.add("selected");
                }
            }

            // CLICK
            cell.onclick = () => {
                if (isFuture) return;

                if (state.mode === "single") {
                    state.startDate = dateObj;
                    state.endDate = null;
                    onSelect(state.startDate);
                }

                if (state.mode === "range") {

                    if (!state.startDate || state.endDate) {
                        state.startDate = dateObj;
                        state.endDate = null;
                    } else if (dateObj >= state.startDate) {
                        state.endDate = dateObj;
                        onSelect(state.startDate, state.endDate);
                    } else {
                        state.startDate = dateObj;
                        state.endDate = null;
                    }
                }

                render();
            };

            grid.appendChild(cell);
        }

        container.appendChild(grid);
    }

    render();
}
ZOHO.embeddedApp.init();